import React from 'react';
import { StyleSheet, View, Button, Alert } from 'react-native';
import { ImagePicker, Permissions } from 'expo';

export default class App extends React.Component {
  buttonPressed = async () => {    
    const result = await Permissions.getAsync(Permissions.CAMERA);
    console.log(result);
  
    Alert.alert(
      'Permissions.getAsync(Permissions.CAMERA)',
      JSON.stringify(result),
      
      [
        {
          text: 'Okay',
          onPress: () => {},
        },
      ],
      { cancelable: false }
    );
    // Immediately returns
    // Object {
    //   "expires": "never",
    //   "status": "undetermined",
    // }
    const result2 = await Permissions.getAsync(Permissions.CAMERA_ROLL);
    console.log(result2);
    // Immediately returns
    // Object {
    //   "expires": "never",
    //   "status": "undetermined",
    // }
    Alert.alert(
      'Permissions.getAsync(Permissions.CAMERA_ROLL)',
      JSON.stringify(result2),
      [
        {
          text: 'Okay',
          onPress: () => {},
        },
      ],
      { cancelable: false }
    );
    
              await ImagePicker.launchImageLibraryAsync({
              mediaTypes: ImagePicker.MediaTypeOptions.Images,
              allowsEditing: true,
              aspect: [1, 1],
              base64: true,
            });
  }

  render() {
    return (
      <View style={styles.container}>
        <Button
          title={'Click Me'}
          onPress={this.buttonPressed}
        />
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
});

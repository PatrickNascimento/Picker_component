export const SHOPIFY_STOREFRONT_ACCESS_TOKEN = 'df0f6c737752861cf7c92332a5ff60c8'
export const SHOPIFY_GRAPHQL_URL = 'https://aslkdfjlasdfj.myshopify.com/api/graphql'
import styled from 'styled-components';
import { ScrollView } from 'react-native'

export const StyledScrollView = styled(ScrollView)`
    padding-top: 15px;,
`



import ColorsConst from './Colors'

export const Colors = ColorsConst
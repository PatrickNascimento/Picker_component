import axios from 'axios'
import {Colors} from './constants'
import React, {Component} from 'react'
import {Button} from './components/Button'
import {Ionicons} from '@expo/vector-icon'
import {View, TextInput, StyleSheet} from 'react-native'

const BASE_API = 'http://porthubserver.herokuapp.com/api/'
const USER_API = `${BASE_API}user/`

export default class LoginForm extends Component {
  state = {
    error: null,
    result: null,
    username: 'none',
    pin: 'none',
    currentUser: 'none',
  };

  getUser = () => axios.get(USER_API + this.state.username)
  getPin = () => axios.get(USER_API + this.state.pin)

  userLogin = () => { this.getUser( response => {console.log(response)}).catch( error => {console.log(error)})}


    render() {
      return (
        <View style={styles.container}>

          <View style={styles.inputContainer}>
            <Ionicons
              style={styles.inputIcon}
              name="md-mail"
              size={20}
              color={Colors.mainBlue}/>

            <TextInput
              style={styles.input}
              autoCapitalize="none"
              onSubmitEditing={() => this.passwordInput.focus()}
              autoCorrect={false}
              keyboardType="default"
              returnKeyType="next"
              placeholder="Username"
              selectionColor='white'
              keyboardAppearance='dark'
              placeholderTextColor={Colors.tintColor}
              onChangeText={(text) => this.setState({ username:text })}
              />
          </View>

          <View style={styles.inputContainer}>
            <Ionicons
              style={styles.inputIcon}
              name="md-lock"
              size={20}
              color={Colors.mainBlue}/>

            <TextInput
              style={styles.input}
              returnKeyType="go"
              ref={input => (this.passwordInput = input)}
              placeholder="PIN"
              placeholderTextColor={Colors.tintColor}
              selectionColor='white'
              keyboardAppearance='dark'
              secureTextEntry
              onChangeText={(text) => this.setState({ pin: text })}
              />
          </View>

          <Button onPress={this.userLogin} title="LOGIN"/>

        </View>
      );
    }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 50
  },
  inputContainer: {
    marginBottom: 30,
    flexDirection: 'row',
    backgroundColor: 'transparent',
    borderBottomWidth: 3,
    borderBottomColor: Colors.tintColor,
    alignItems: 'baseline'
  },
  inputIcon: {
    paddingRight: 10,
    bottom: 0
  },
  input: {
    fontSize: 20,
    flex: 1,
    color: '#fff',
    fontWeight: '700',
    bottom: 0
  }
});
 // 0.17.1



 // ERROR. The Expo team has been notified.
undefined // ERROR. The Expo team has been notified.



undefined // ERROR. The Expo team has been notified.